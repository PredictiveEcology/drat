Known issues: https://github.com/PredictiveEcology/map/issues

version 0.0.3
=============

* maximum number of threads for parallel operations limited by package option `map.maxNumCores`, which defaults to `min(getOption("Ncpus"), parallel::detectCores())`.

version 0.0.1
=============

* initial development version
