#' pedev
#'
#' @import igraph
#' @import methods
"_PACKAGE"
