# pedev

Miscellaneous development tools developed by the Predictive Ecology Group (<https://predictiveecology.org>).
  
<!-- badges: start -->
[![R build status](https://github.com/PredictiveEcology/pedev/workflows/R-CMD-check/badge.svg)](https://github.com/PredictiveEcology/pedev/actions)
[![Codecov test coverage](https://codecov.io/gh/PredictiveEcology/pedev/branch/master/graph/badge.svg)](https://codecov.io/gh/PredictiveEcology/pedev?branch=master)
<!-- badges: end -->
