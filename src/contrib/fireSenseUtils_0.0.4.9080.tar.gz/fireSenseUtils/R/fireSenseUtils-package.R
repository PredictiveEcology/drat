#' \code{fireSenseUtils} package
#'
#' Utilities for working with the 'fireSense' group of 'SpaDES' modules.
#'
#' @import methods
"_PACKAGE"
