#' Helpers for installing \code{SpaDES} package and module dependencies
#'
#' @import methods
#' @rdname SpaDES.install-package
"_PACKAGE"
