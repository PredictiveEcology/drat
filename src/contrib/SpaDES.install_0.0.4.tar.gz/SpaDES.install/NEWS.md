Known issues: https://github.com/PredictiveEcology/SpaDES.install/issues

version 0.0.4
=============

* A new package, aiming to aid installing and updating the SpaDES ecosystem of packages and the `reqdPkgs` of SpaDES modules in a project

