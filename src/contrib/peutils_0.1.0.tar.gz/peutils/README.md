# `peutils`

Utilities developed by the Predictive Ecology Group.
These are intended to be _dependency-free_ (i.e., do not import from contributed R packages).

<!-- badges: start -->
[![R build status](https://github.com/PredictiveEcology/peutils/workflows/R-CMD-check/badge.svg)](https://github.com/PredictiveEcology/peutils/actions)
[![Codecov test coverage](https://codecov.io/gh/PredictiveEcology/peutils/branch/master/graph/badge.svg)](https://codecov.io/gh/PredictiveEcology/peutils?branch=master)
<!-- badges: end -->
