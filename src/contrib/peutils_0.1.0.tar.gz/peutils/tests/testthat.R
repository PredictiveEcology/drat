library(testthat)
library(peutils)

test_check("peutils")
