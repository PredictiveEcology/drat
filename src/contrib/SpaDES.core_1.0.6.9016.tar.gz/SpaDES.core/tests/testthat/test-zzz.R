options(getOption("spades.temp.debug"))
