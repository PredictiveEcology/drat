.onUnload <- function(libpath) {
  library.dynam.unload("CBMutils", libpath)
}
