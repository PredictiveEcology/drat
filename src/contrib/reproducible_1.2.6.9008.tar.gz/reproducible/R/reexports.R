#' @importFrom Require Require
#' @export
Require::Require

#' @importFrom Require pkgDep
#' @export
Require::pkgDep

#' @importFrom Require checkPath
#' @export
Require::checkPath

#' @importFrom Require normPath
#' @export
Require::normPath

#' @importFrom Require trimVersionNumber
#' @export
Require::trimVersionNumber

#' @importFrom Require tempfile2
#' @export
Require::tempfile2

#' @importFrom Require tempdir2
#' @export
Require::tempdir2

