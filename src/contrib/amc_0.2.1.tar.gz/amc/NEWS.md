Known issues: https://github.com/PredictiveEcology/amc/issues

version 0.2.1
=============

- move `notify_slack()` to `SpaDES.project`

version 0.2.0
=============

- drop support for R 3.5 (requirement of several dependencies)
- remove deprecated and defunct functions
- add `notify_slack()`

version 0.1.1
=============

- add `flink` for creating file (and directory) symlinks
- don't write row numbers in download checksum files
- numerous bug fixes

version 0.1.0
=============

- first version
