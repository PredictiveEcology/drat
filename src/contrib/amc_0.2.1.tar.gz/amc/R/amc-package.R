#' Alex's Miscellaneous Code
#'
#' @import methods
#' @name amc-package
#'
"_PACKAGE"
