test_that("all examples work", {
  test_examples(path = "../../man")
})
