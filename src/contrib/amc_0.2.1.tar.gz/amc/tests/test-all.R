library(testthat)
test_check("amc")
