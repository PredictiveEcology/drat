library(testthat)
library(LandR)

test_check("LandR")
