library(testthat)
test_check("quickPlot")
