#' \code{fireSenseUtils} package
#'
#' DESCRIPTION NEEDED
#'
#' @import methods
"_PACKAGE"
