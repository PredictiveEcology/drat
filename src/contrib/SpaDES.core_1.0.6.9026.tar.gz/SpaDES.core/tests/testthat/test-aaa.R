aa <- options(spades.debug = FALSE)
options("spades.temp.debug" = aa)
