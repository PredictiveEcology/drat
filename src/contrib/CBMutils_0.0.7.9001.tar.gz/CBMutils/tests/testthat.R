library(testthat)
library(CBMutils)

test_check("CBMutils")
