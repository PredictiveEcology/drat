library(testthat)
library(fireSenseUtils)

test_check("fireSenseUtils")
