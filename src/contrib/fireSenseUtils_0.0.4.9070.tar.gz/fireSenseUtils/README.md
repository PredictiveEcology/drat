# fireSenseUtils

<!-- badges: start -->
[![R build status](https://github.com/PredictiveEcology/fireSenseUtils/workflows/R-CMD-check/badge.svg)](https://github.com/PredictiveEcology/fireSenseUtils/actions)
<!-- badges: end -->

The goal of `fireSenseUtils` is to ...

## Installation

You can install the development version of `fireSenseUtils` from GitHub with:

``` r
remotes::install_github("PredictiveEcology/fireSenseUtils")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(fireSenseUtils)
## basic example code
```
