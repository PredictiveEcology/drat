#' \code{usefulFuns} package
#'
#' @import ggplot2
#' @import methods
#' @name usefulFuns-package
#' @rdname usefulFuns-package
"_PACKAGE"
