#' \code{pemisc} package
#'
#' Miscellaneous utilities developed by the Predictive Ecology Group
#' (\url{https://predictiveecology.org}).
#'
#' @import methods
#' @name pemisc-package
#' @rdname pemisc-package
#' @aliases pemisc
NULL
