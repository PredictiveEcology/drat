inside <- function(shp, x, y, clockwise=TRUE, all=FALSE) .Call(shp_inside, shp, x, y, clockwise, all)
