Known issues: https://github.com/PredictiveEcology/peutils/issues

version 0.0.1
=============

* new package for misc utils, intended as a temporary location for new functions etc. before being moved to their "official" home in other packages developed by the PE group
