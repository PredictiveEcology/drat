Known issues: https://github.com/PredictiveEcology/peutils/issues

version 0.1.0
=============

* new package for _dependency-free_ helper utilities.
